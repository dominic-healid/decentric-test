//
//  TasksViewController.swift
//  TechnicalExam
//
//  Created by Klein Noctis on 10/30/20.
//  Copyright © 2020 Klein Noctis. All rights reserved.
//

import UIKit

class TasksViewController: UIViewController, TaskView {
    func displayTasks(tasks: [Task]) {
        
    }
    
    func addTaskToList(task: Task) {
        
    }
    
    func removeTaskFromList(task: Task) {
        
    }
    
    func updateTaskInList(task: Task) {
        
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

        /**
         *   Finish this simple task recording app
         *   1. Make sure all defects are fixed
         *   2. Show a view (can be UIAlertController or any) that can add/edit the task.
         *   3. Show the added task in a UITableView/CollectionView
         *   4. Allow the user to toggle it as completed
         *   5. Allow the user to delete a task
         *
         **/
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
