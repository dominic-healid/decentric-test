//
//  TaskPresenter.swift
//  TechnicalExam
//
//  Created by Klein Noctis on 10/30/20.
//  Copyright © 2020 Klein Noctis. All rights reserved.
//

import Foundation

class TasksViewPresenter : TaskPresenter{
    let taskProvider = TaskLocalServiceProvider()
    
    func taskClicked() {
        
    }
    
    func savedTask(task: Task) {
        
    }
    
    func checkedTask(taskId: Int) {
        
    }
    
    func uncheckedTask(taskId: Int) {
        
    }
    
    func deletedTask(taskId: Int) {
        
    }
    
    
}
